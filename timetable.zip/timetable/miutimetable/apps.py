from django.apps import AppConfig


class MiutimetableConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'miutimetable'
